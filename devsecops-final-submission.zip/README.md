# ✅ Final Submission Summary (Evaluator Quick View)

This repository represents a **production-style DevSecOps implementation** for a containerized Node.js application, validated and executed on a **local Kubernetes cluster (Minikube)**.

The project demonstrates secure containerization, CI/CD security gates, Infrastructure as Code validation, Kubernetes hardening, observability, and risk-aware security documentation.

---

## 🎯 Objective (What This Submission Proves)

- Secure Docker image creation using best practices  
- Automated CI/CD security scanning with enforced gates  
- Infrastructure as Code design with local validation  
- Kubernetes hardening with namespace isolation and NetworkPolicy  
- Runtime observability and alerting  
- Practical security risk identification and documentation  

---

## 🔐 Security Controls Implemented (At a Glance)

- Multi-stage Docker builds with non-root containers  
- Trivy image scanning with HIGH and CRITICAL severity visibility  
- CI/CD pipeline blocks promotion on CRITICAL vulnerabilities  
- Terraform validation with Checkov security scanning  
- Kubernetes namespace isolation (`app`)  
- NetworkPolicy enforced using a **default-deny** model  
- Resource limits and PodDisruptionBudget applied  
- Prometheus and Grafana for monitoring and observability  

---

## 🔍 Validation & Evidence

- Trivy scan output: `docker/trivy.txt`  
- Terraform validation: `terraform validate`  
- Checkov results: `checkov-results.txt`  
- Kubernetes manifests validated using dry-run  
- NetworkPolicy verified on running Minikube cluster  

---

# 🚀 DevSecOps Evaluation Task

## 📌 Overview

This project demonstrates a complete end-to-end DevSecOps workflow for a Node.js application deployed in a secure Kubernetes environment running entirely on a local system.

---

## 🔒 Important Note

- No cloud provider is used (AWS, Azure, GCP, etc.)  
- All components run locally  
- Infrastructure definitions are validated locally for demonstration purposes only  
- The goal is to show secure design, automation, and observability similar to production systems, without using any cloud services  

---

## 🎯 Project Scope

This project covers:

- Secure Docker image creation  
- Automated CI/CD security checks  
- Local Kubernetes deployment with hardening  
- Infrastructure as Code (local validation)  
- Monitoring and observability  
- Security and compliance documentation  

---

## 🧩 DevSecOps Workflow


Source Code
↓
Docker Image Build
↓
Container Security Scan (Trivy)
↓
CI/CD Pipeline (GitHub Actions)
↓
Hardened Image
↓
Local Kubernetes Deployment (Minikube)
↓
Monitoring (Prometheus + Grafana)



---

## 🛠 Tools Used

- Docker
- Trivy
- GitHub Actions
- Terraform (local validation only)
- Checkov / tfsec
- Kubernetes (Minikube)
- kubectl
- Prometheus
- Grafana
- Node.js
- MongoDB

---

## 📁 Project Structure


.
├── docker/
│ ├── Dockerfile
│ └── trivy.txt
├── .github/workflows/
│ └── devsecops-pipeline.yml
├── terraform/
│ ├── main.tf
│ ├── variables.tf
│ └── outputs.tf
├── k8s/
│ ├── deployment.yaml
│ ├── service.yaml
│ ├── ingress.yaml
│ ├── nodeapp-network-policy.yaml
├── monitoring/
│ ├── prometheus.yaml
│ └── grafana.yaml
├── report/
│ └── Security-Compliance-Report.md
└── README.md



---

## 🔒 Docker & Image Security

- Minimal base image
- Multi-stage Docker build
- Non-root container execution
- Reduced image size and attack surface

### Build Image
```bash
docker build -t secure-node-app .


Run Container (Local Test)

docker run -p 3000:3000 secure-node-app


🔍 Container Security Scanning

trivy image secure-node-app

Scan output saved in:

docker/trivy.txt

🔁 CI/CD Pipeline

Implemented using GitHub Actions

Performs Docker build and Trivy scan

Blocks image promotion on CRITICAL vulnerabilities

Runs automatically on every push

Pipeline file:

.github/workflows/devsecops-pipeline.yml

🛠 Infrastructure as Code (Local Only)

cd terraform
terraform init
terraform validate


Security scan:

checkov -d terraform/

☸ Kubernetes Deployment (Local)

minikube start
kubectl apply -f k8s/
kubectl apply --dry-run=client -f k8s/
kubectl get pods -n app
kubectl get networkpolicy -n app


🔐 Kubernetes Security Hardening

Non-root containers

Pod and container security contexts

CPU and memory requests/limits

NetworkPolicy with default-deny model

Controlled service exposure


📊 Observability & Monitoring

kubectl apply -f monitoring/
kubectl get pods -n monitoring


Prometheus for metrics collection

Grafana for visualization

Monitors CPU, memory, and pod health


🛡 Security & Compliance Summary

Reduced container attack surface

Automated vulnerability scanning

CI/CD security gates enforced

Kubernetes runtime hardening applied

Monitoring added for visibility

Detailed report:

report/Security-Compliance-Report.md


